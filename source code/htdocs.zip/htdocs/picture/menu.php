	<h2>在线相册管理</h2>
	<a href="index.php">发布相册</a>
	<a href="show.php">浏览相册</a>
	<hr/>