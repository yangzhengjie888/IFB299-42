<?php
	$output='';
  
  $output.= "<form enctype='multipart/form-data' method='post' action='upload1.php' name='upform' >
  upload files:
  <input name='upfile' type='file' size='80' />
 
  <input type='submit' value='upload'><br>
  These kinds of files were supported: pdf, jpg, mp3, mp4
</form>"
?>


<html>
<body>
  
	  <?php include "home.html";

?>
</body>
</html>

